import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Button;

public class CantineEtudiant {

	protected Shell shlServiceDeCantine;
	private Table table;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			CantineEtudiant window = new CantineEtudiant();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlServiceDeCantine.open();
		shlServiceDeCantine.layout();
		while (!shlServiceDeCantine.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlServiceDeCantine = new Shell();
		shlServiceDeCantine.setSize(654, 424);
		shlServiceDeCantine.setText("Service de cantine Etudiant ");
		
		table = new Table(shlServiceDeCantine, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(0, 0, 645, 344);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnNom = new TableColumn(table, SWT.CENTER);
		tblclmnNom.setWidth(77);
		tblclmnNom.setText("Nom");
		
		TableColumn tblclmnPrnom = new TableColumn(table, SWT.NONE);
		tblclmnPrnom.setWidth(100);
		tblclmnPrnom.setText("Prenom");
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(100);
		tblclmnNewColumn.setText("Cantine");
		
		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setText("Type");
		tblclmnNewColumn_1.setWidth(100);
		
		TableColumn tblclmnRgimeParticulier = new TableColumn(table, SWT.NONE);
		tblclmnRgimeParticulier.setText("Regime ");
		tblclmnRgimeParticulier.setWidth(100);
		
		TableColumn tblclmnNewColumn_2 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_2.setWidth(66);
		tblclmnNewColumn_2.setText("Classe");
		
		TableColumn tblclmnSommeTotale = new TableColumn(table, SWT.NONE);
		tblclmnSommeTotale.setWidth(100);
		tblclmnSommeTotale.setText("Somme totale");
		
		Button btnUpdate = new Button(shlServiceDeCantine, SWT.NONE);
		btnUpdate.setBounds(496, 351, 75, 25);
		btnUpdate.setText("Update");

	}

}
