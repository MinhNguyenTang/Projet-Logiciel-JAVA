import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public class Accueil {

	protected Shell shell;
	private Table table;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Accueil window = new Accueil();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(558, 408);
		shell.setText("SWT Application");
		
		Button btnAdd = new Button(shell, SWT.NONE);
		btnAdd.setBounds(457, 29, 75, 25);
		btnAdd.setText("Add");
		
		Button btnDelete = new Button(shell, SWT.NONE);
		btnDelete.setBounds(457, 100, 75, 25);
		btnDelete.setText("Delete");
		
		Button btnUpdate = new Button(shell, SWT.NONE);
		btnUpdate.setBounds(457, 171, 75, 25);
		btnUpdate.setText("Update");
		
		Button btnSubmit = new Button(shell, SWT.NONE);
		btnSubmit.setBounds(457, 295, 75, 25);
		btnSubmit.setText("Submit");
		
		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(10, 9, 441, 351);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnNom = new TableColumn(table, SWT.CENTER);
		tblclmnNom.setWidth(64);
		tblclmnNom.setText("Nom");
		
		TableColumn tblclmnPnom = new TableColumn(table, SWT.CENTER);
		tblclmnPnom.setWidth(76);
		tblclmnPnom.setText("P\u00E9nom");
		
		TableColumn tblclmnClasse = new TableColumn(table, SWT.CENTER);
		tblclmnClasse.setWidth(100);
		tblclmnClasse.setText("Classe");
		
		TableColumn tblclmnNEtudiant = new TableColumn(table, SWT.CENTER);
		tblclmnNEtudiant.setWidth(100);
		tblclmnNEtudiant.setText("N\u00B0 Etudiant");
		
		TableColumn tblclmnNTlphone = new TableColumn(table, SWT.NONE);
		tblclmnNTlphone.setWidth(100);
		tblclmnNTlphone.setText("N\u00B0 T\u00E9l\u00E9phone");

	}
}
