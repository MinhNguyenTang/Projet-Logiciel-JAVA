import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Admin {

	protected Shell shlIdentification;
	private Text text;
	private Text text_1;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Admin window = new Admin();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlIdentification.open();
		shlIdentification.layout();
		while (!shlIdentification.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlIdentification = new Shell();
		shlIdentification.setSize(537, 300);
		shlIdentification.setText("Identification");
		
		Label lblNom = new Label(shlIdentification, SWT.NONE);
		lblNom.setBounds(21, 38, 103, 15);
		lblNom.setText("Nom d'utlisateur :");
		
		Label lblMotDePasse = new Label(shlIdentification, SWT.NONE);
		lblMotDePasse.setBounds(21, 83, 82, 15);
		lblMotDePasse.setText("Mot de passe :");
		
		text = new Text(shlIdentification, SWT.BORDER);
		text.setBounds(128, 35, 383, 21);
		
		text_1 = new Text(shlIdentification, SWT.BORDER);
		text_1.setBounds(109, 80, 402, 21);
		
		Button btnVoirMotDe = new Button(shlIdentification, SWT.CHECK);
		btnVoirMotDe.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnVoirMotDe.setBounds(109, 104, 115, 16);
		btnVoirMotDe.setText("Voir mot de passe");
		
		Button btnNewButton = new Button(shlIdentification, SWT.NONE);
		btnNewButton.setBounds(293, 189, 75, 25);
		btnNewButton.setText("Valider");
		
		Button btnAnnuler = new Button(shlIdentification, SWT.NONE);
		btnAnnuler.setBounds(149, 189, 75, 25);
		btnAnnuler.setText("Annuler");

	}
}
