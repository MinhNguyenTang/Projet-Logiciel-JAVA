import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Button;

public class CantineProfesseur {

	protected Shell shlService;
	private Table table;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			CantineProfesseur window = new CantineProfesseur();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlService.open();
		shlService.layout();
		while (!shlService.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlService = new Shell();
		shlService.setSize(606, 415);
		shlService.setText("Service de cantine Professeur");
		
		table = new Table(shlService, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(0, 0, 590, 341);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnNom = new TableColumn(table, SWT.NONE);
		tblclmnNom.setWidth(74);
		tblclmnNom.setText("Nom");
		
		TableColumn tblclmnPrnom = new TableColumn(table, SWT.NONE);
		tblclmnPrnom.setWidth(100);
		tblclmnPrnom.setText("Prenom");
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(85);
		tblclmnNewColumn.setText("Type");
		
		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setText("Jours \u00E0 la cantine");
		tblclmnNewColumn_1.setWidth(122);
		
		TableColumn tblclmnRgime = new TableColumn(table, SWT.NONE);
		tblclmnRgime.setText("R\u00E9gime");
		tblclmnRgime.setWidth(100);
		
		TableColumn tblclmnSommeTotale = new TableColumn(table, SWT.NONE);
		tblclmnSommeTotale.setWidth(100);
		tblclmnSommeTotale.setText("Somme totale");
		
		Button btnUpdate = new Button(shlService, SWT.NONE);
		btnUpdate.setBounds(471, 347, 75, 25);
		btnUpdate.setText("Update");

	}
}
